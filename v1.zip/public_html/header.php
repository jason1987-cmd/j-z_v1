<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Your Website</title>
  <style>
    body {
      margin: 0;
      font-family: Arial, sans-serif;
      padding-top: 60px; /* Adjust padding to accommodate fixed header */
    }

    header {
      background-color: #607274;
      color: white;
      padding: 10px;
      text-align: center;
      position: fixed;
      width: 100%;
      top: 0;
      z-index: 1000;
    }

    #logo {
      max-width: 100px; /* Adjust the maximum width of your logo */
      height: auto;
      vertical-align: middle;
      border-radius: 50%; /* Make the logo round */
    }

    #header-text {
      display: inline-block;
      margin-left: 10px;
      vertical-align: middle;
    }

    /* Adjust content margin to prevent it from being hidden behind the fixed header */
    .content {
      margin-top: 60px; /* Should match the padding-top of the body */
    }
  </style>
</head>
<body>

  <header>
    <img src="logo.jpg" alt="Your Logo" id="logo">
    <h1 id="header-text">J&Z Milktea House</h1>
  </header>

  <div class="content">
    <!-- Rest of your HTML content goes here -->
  </div>

</body>
</html>
